// ============================================================================
// Snowflake Active/DR Resilience Layer
// ----------------------------------------------------------------------------
// - Endpoints (account locators) come from Azure App Configuration.
// - Credentials (passcode + certificate) come from Azure Key Vault and are
//   shared across both Primary and DR (same identity, different endpoint).
// - Failover is driven entirely in-process by a Polly circuit breaker, with
//   an optional Redis flag to make the "primary is down" signal instant
//   across all Azure Container Apps replicas.
// ============================================================================

using System.Data;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.CircuitBreaker;
using Snowflake.Data.Client;
using StackExchange.Redis;

namespace CfcInsights.Infrastructure.Snowflake;

public enum SnowflakeTarget
{
    Primary,
    DR
}

public sealed record SnowflakeCredentials(string User, string Passcode, string? CertificatePem);

// ----------------------------------------------------------------------------
// Credentials — Key Vault, cached in memory (shared by Primary and DR)
// ----------------------------------------------------------------------------
public sealed class SnowflakeCredentialProvider
{
    private const string CacheKey = "snowflake:credentials";
    private static readonly TimeSpan CacheDuration = TimeSpan.FromMinutes(30);

    private readonly SecretClient _keyVaultClient;
    private readonly IMemoryCache _cache;
    private readonly ILogger<SnowflakeCredentialProvider> _logger;

    public SnowflakeCredentialProvider(
        SecretClient keyVaultClient,
        IMemoryCache cache,
        ILogger<SnowflakeCredentialProvider> logger)
    {
        _keyVaultClient = keyVaultClient;
        _cache = cache;
        _logger = logger;
    }

    public async Task<SnowflakeCredentials> GetAsync(CancellationToken ct = default)
    {
        var cached = await _cache.GetOrCreateAsync(CacheKey, async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = CacheDuration;

            try
            {
                var user = await _keyVaultClient.GetSecretAsync("snowflake-user", cancellationToken: ct);
                var passcode = await _keyVaultClient.GetSecretAsync("snowflake-passcode", cancellationToken: ct);

                string? certPem = null;
                try
                {
                    var cert = await _keyVaultClient.GetSecretAsync("snowflake-certificate", cancellationToken: ct);
                    certPem = cert.Value.Value;
                }
                catch (Azure.RequestFailedException ex) when (ex.Status == 404)
                {
                    // Cert-based auth not configured — passcode-only is fine.
                }

                return new SnowflakeCredentials(user.Value.Value, passcode.Value.Value, certPem);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load Snowflake credentials from Key Vault");
                throw new SnowflakeCredentialException("Unable to load Snowflake credentials from Key Vault", ex);
            }
        });

        return cached!;
    }

    /// <summary>Call this from a Key Vault rotation event handler (Event Grid) to avoid
    /// serving a stale credential for up to CacheDuration after rotation.</summary>
    public void InvalidateCache() => _cache.Remove(CacheKey);
}

// ----------------------------------------------------------------------------
// Connection factory — App Configuration for endpoints, Key Vault for creds
// ----------------------------------------------------------------------------
public interface ISnowflakeConnectionFactory
{
    Task<IDbConnection> CreateAsync(SnowflakeTarget target, CancellationToken ct = default);
}

public sealed class SnowflakeConnectionFactory : ISnowflakeConnectionFactory
{
    private readonly IConfiguration _config; // backed by Azure App Configuration
    private readonly SnowflakeCredentialProvider _credentials;
    private readonly ILogger<SnowflakeConnectionFactory> _logger;

    public SnowflakeConnectionFactory(
        IConfiguration config,
        SnowflakeCredentialProvider credentials,
        ILogger<SnowflakeConnectionFactory> logger)
    {
        _config = config;
        _credentials = credentials;
        _logger = logger;
    }

    public async Task<IDbConnection> CreateAsync(SnowflakeTarget target, CancellationToken ct = default)
    {
        var account = target switch
        {
            SnowflakeTarget.Primary => _config["Snowflake:Primary:Account"],
            SnowflakeTarget.DR => _config["Snowflake:DR:Account"],
            _ => throw new ArgumentOutOfRangeException(nameof(target))
        };

        if (string.IsNullOrWhiteSpace(account))
            throw new InvalidOperationException($"No Snowflake account configured for target '{target}'. " +
                                                 $"Expected App Configuration key 'Snowflake:{target}:Account'.");

        var creds = await _credentials.GetAsync(ct);

        var builder = new SnowflakeDbConnectionStringBuilder
        {
            Account = account,
            User = creds.User,
            Warehouse = _config["Snowflake:Warehouse"],
            Db = _config["Snowflake:Database"],
            Schema = _config["Snowflake:Schema"],
            Role = _config["Snowflake:Role"],
            ConnectionTimeout = int.TryParse(_config["Snowflake:ConnectionTimeoutSeconds"], out var t) ? t : 15
        };

        if (!string.IsNullOrWhiteSpace(creds.CertificatePem))
        {
            builder.Authenticator = "SNOWFLAKE_JWT";
            builder.PrivateKeyPem = creds.CertificatePem;
        }
        else
        {
            builder.Password = creds.Passcode;
        }

        _logger.LogDebug("Opening Snowflake connection to {Target} ({Account})", target, account);

        var conn = new SnowflakeDbConnection(builder.ConnectionString);
        await conn.OpenAsync(ct);
        return conn;
    }
}

// ----------------------------------------------------------------------------
// Resilient executor — retry + circuit breaker + timeout + cluster-wide flag
// ----------------------------------------------------------------------------
public interface ISnowflakeQueryExecutor
{
    Task<T> ExecuteAsync<T>(
        Func<IDbConnection, Task<T>> query,
        string operationName,
        CancellationToken ct = default);
}

public sealed class ResilientSnowflakeQueryExecutor : ISnowflakeQueryExecutor
{
    private const string RedisPrimaryDownKey = "snowflake:primary:down";
    private static readonly TimeSpan PrimaryDownFlagTtl = TimeSpan.FromSeconds(30);

    // Per-process breaker state — cheap, fast, first line of defense.
    private static readonly CircuitBreakerStateProvider PrimaryBreakerState = new();

    private readonly ISnowflakeConnectionFactory _connectionFactory;
    private readonly IConnectionMultiplexer? _redis; // optional — pass null to skip cluster-wide coordination
    private readonly ILogger<ResilientSnowflakeQueryExecutor> _logger;
    private readonly ResiliencePipeline _primaryPipeline;
    private readonly ResiliencePipeline _drPipeline;

    public ResilientSnowflakeQueryExecutor(
        ISnowflakeConnectionFactory connectionFactory,
        ILogger<ResilientSnowflakeQueryExecutor> logger,
        IConnectionMultiplexer? redis = null)
    {
        _connectionFactory = connectionFactory;
        _redis = redis;
        _logger = logger;

        _primaryPipeline = new ResiliencePipelineBuilder()
            .AddRetry(new Polly.Retry.RetryStrategyOptions
            {
                MaxRetryAttempts = 2,
                Delay = TimeSpan.FromMilliseconds(200),
                BackoffType = DelayBackoffType.Exponential,
                ShouldHandle = new PredicateBuilder().Handle<SnowflakeDbException>(IsTransient)
            })
            .AddCircuitBreaker(new Polly.CircuitBreaker.CircuitBreakerStrategyOptions
            {
                FailureRatio = 0.5,
                SamplingDuration = TimeSpan.FromSeconds(30),
                MinimumThroughput = 4,
                BreakDuration = PrimaryDownFlagTtl,
                StateProvider = PrimaryBreakerState,
                ShouldHandle = new PredicateBuilder().Handle<SnowflakeDbException>()
            })
            .AddTimeout(TimeSpan.FromSeconds(15))
            .Build();

        _drPipeline = new ResiliencePipelineBuilder()
            .AddRetry(new Polly.Retry.RetryStrategyOptions
            {
                MaxRetryAttempts = 1,
                Delay = TimeSpan.FromMilliseconds(200),
                ShouldHandle = new PredicateBuilder().Handle<SnowflakeDbException>(IsTransient)
            })
            .AddTimeout(TimeSpan.FromSeconds(15))
            .Build();
    }

    public async Task<T> ExecuteAsync<T>(
        Func<IDbConnection, Task<T>> query,
        string operationName,
        CancellationToken ct = default)
    {
        using var activity = SnowflakeTelemetry.Source.StartActivity("snowflake.query");
        activity?.SetTag("snowflake.operation", operationName);

        var primaryMarkedDownClusterWide = await IsPrimaryMarkedDownAsync();
        var primaryBreakerOpen = PrimaryBreakerState.CircuitState is CircuitState.Open;

        if (!primaryMarkedDownClusterWide && !primaryBreakerOpen)
        {
            try
            {
                var result = await _primaryPipeline.ExecuteAsync(async token =>
                {
                    using var conn = await _connectionFactory.CreateAsync(SnowflakeTarget.Primary, token);
                    return await query(conn);
                }, ct);

                activity?.SetTag("snowflake.target", "primary");
                return result;
            }
            catch (Exception ex) when (ex is SnowflakeDbException or BrokenCircuitException)
            {
                _logger.LogWarning(ex,
                    "Primary Snowflake failed for {Operation}; failing over to DR", operationName);
                await MarkPrimaryDownAsync();
            }
        }
        else
        {
            _logger.LogInformation(
                "Primary Snowflake currently marked down; routing {Operation} to DR", operationName);
        }

        try
        {
            var result = await _drPipeline.ExecuteAsync(async token =>
            {
                using var conn = await _connectionFactory.CreateAsync(SnowflakeTarget.DR, token);
                return await query(conn);
            }, ct);

            activity?.SetTag("snowflake.target", "dr");
            activity?.SetTag("snowflake.failover_occurred", true);
            return result;
        }
        catch (Exception ex)
        {
            activity?.SetStatus(System.Diagnostics.ActivityStatusCode.Error);
            _logger.LogError(ex,
                "Both primary and DR Snowflake failed for {Operation}", operationName);
            throw new SnowflakeUnavailableException(operationName, ex);
        }
    }

    private async Task<bool> IsPrimaryMarkedDownAsync()
    {
        if (_redis is null) return false;

        try
        {
            var db = _redis.GetDatabase();
            return await db.KeyExistsAsync(RedisPrimaryDownKey);
        }
        catch
        {
            // Redis itself being unavailable should never block a Snowflake query —
            // fall back to the local circuit breaker's view of the world.
            return false;
        }
    }

    private async Task MarkPrimaryDownAsync()
    {
        if (_redis is null) return;

        try
        {
            var db = _redis.GetDatabase();
            await db.StringSetAsync(RedisPrimaryDownKey, "1", PrimaryDownFlagTtl);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to set cluster-wide Snowflake primary-down flag in Redis");
        }
    }

    private static bool IsTransient(SnowflakeDbException ex) =>
        ex.Message.Contains("timeout", StringComparison.OrdinalIgnoreCase)
        || ex.Message.Contains("connection", StringComparison.OrdinalIgnoreCase)
        || ex.Message.Contains("unreachable", StringComparison.OrdinalIgnoreCase);
}

// ----------------------------------------------------------------------------
// Exceptions
// ----------------------------------------------------------------------------
public sealed class SnowflakeUnavailableException : Exception
{
    public string Operation { get; }

    public SnowflakeUnavailableException(string operation, Exception inner)
        : base($"Both Primary and DR Snowflake accounts failed for operation '{operation}'.", inner)
    {
        Operation = operation;
    }
}

public sealed class SnowflakeCredentialException : Exception
{
    public SnowflakeCredentialException(string message, Exception inner) : base(message, inner) { }
}

// ----------------------------------------------------------------------------
// Telemetry — OTel ActivitySource for Dynatrace ingestion
// ----------------------------------------------------------------------------
public static class SnowflakeTelemetry
{
    public const string SourceName = "CfcInsights.Snowflake";
    public static readonly System.Diagnostics.ActivitySource Source = new(SourceName);
}
