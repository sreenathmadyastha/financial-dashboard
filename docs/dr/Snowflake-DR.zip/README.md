# Snowflake Active/DR Resilience Layer

## What this is
A drop-in resilience layer for CFC Insights' Snowflake connections. It fails over
from the active (primary) Snowflake account to DR automatically when primary
starts failing, and fails back automatically once primary recovers — no manual
intervention, no config write, no deploy.

## Where things live

| Data | Store | Notes |
|---|---|---|
| Snowflake account/endpoint (Primary + DR) | Azure App Configuration | Just the account locator + warehouse/db/schema/role. No credentials, no sentinel key. |
| Snowflake passcode / certificate | Azure Key Vault | Shared identity across Primary and DR — fetched once, cached 30 min. |
| "Is primary currently down" cluster-wide flag | Redis (optional) | TTL-based, self-expiring. Skip this and the system still works via Polly's per-process circuit breaker alone. |
| "Is primary currently down" per-replica | In-memory (Polly `CircuitBreakerStateProvider`) | Always active regardless of Redis. |

## Required App Configuration keys

```
Snowflake:Primary:Account   = xy12345.us-east-1
Snowflake:DR:Account        = xy12345-dr.us-west-2
Snowflake:Warehouse         = CFC_INSIGHTS_WH
Snowflake:Database          = CFC_INSIGHTS_DB
Snowflake:Schema            = PUBLIC
Snowflake:Role              = CFC_INSIGHTS_APP_ROLE
Snowflake:ConnectionTimeoutSeconds = 15
```

## Required Key Vault secrets

```
snowflake-user          — shared across Primary and DR
snowflake-passcode      — used if no certificate is present
snowflake-certificate   — optional; if present, key-pair (JWT) auth is used instead of passcode
```

## Required NuGet packages

```
Snowflake.Data
Polly.Core
Azure.Identity
Azure.Security.KeyVault.Secrets
Microsoft.Azure.AppConfiguration.AspNetCore
StackExchange.Redis          (optional — only if using cluster-wide coordination)
```

## How failover actually happens (no action required)

1. Every query attempt goes through `ISnowflakeQueryExecutor.ExecuteAsync`.
2. It tries Primary first (with retry + timeout), unless the circuit breaker is
   already open or Redis says primary is marked down cluster-wide.
3. Enough failures in a 30s window (50% failure rate, min. 4 attempts) → the
   breaker opens. All *this replica's* future requests skip straight to DR.
   If Redis is configured, this replica also writes a 30s TTL flag so every
   other Container Apps replica routes to DR immediately too, instead of each
   replica independently discovering the outage on its own.
4. After 30s, Polly probes Primary again on the next request. Success closes
   the breaker (and the Redis flag naturally expires); failure keeps it open
   for another 30s window.

## Things to confirm before relying on this in production

- **DR read/write capability**: if DR is a read-only replica that hasn't been
  promoted, writes will fail even though the failover "worked." Fine for
  MoneyIn/MoneyOut reads; needs a guard if you add write paths later.
- **Snowflake driver error codes**: the `IsTransient` check in
  `ResilientSnowflakeQueryExecutor` currently matches on message text
  ("timeout", "connection", "unreachable"). Tighten this to actual
  `SnowflakeDbException` error codes from your driver version for more
  reliable classification.
- **Key Vault rotation**: credentials are cached for 30 minutes. Wire
  `SnowflakeCredentialProvider.InvalidateCache()` to a Key Vault rotation
  Event Grid notification so a rotation doesn't leave a stale-credential
  window on both endpoints simultaneously.
- **Warm DR periodically**: an on-timer `SELECT 1` against DR avoids paying a
  cold connection/warehouse-resume penalty at the exact moment you're already
  degraded.
