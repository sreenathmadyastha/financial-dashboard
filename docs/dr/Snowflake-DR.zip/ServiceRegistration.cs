// ============================================================================
// DI registration for the Snowflake Active/DR resilience layer.
// Call AddSnowflakeResilience(...) from Program.cs.
// ============================================================================

using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using CfcInsights.Infrastructure.Snowflake;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using StackExchange.Redis;

namespace CfcInsights.Infrastructure.Snowflake;

public static class SnowflakeServiceCollectionExtensions
{
    /// <param name="keyVaultUri">e.g. https://cfc-insights-kv.vault.azure.net/</param>
    /// <param name="redisConnectionString">
    /// Pass your existing Redis connection string to enable cluster-wide, cross-replica
    /// failover signaling. Pass null to skip Redis and rely purely on Polly's per-process
    /// circuit breaker (still fully functional, just slightly slower to propagate across
    /// Container Apps replicas).
    /// </param>
    public static IServiceCollection AddSnowflakeResilience(
        this IServiceCollection services,
        IConfiguration configuration,
        Uri keyVaultUri,
        string? redisConnectionString)
    {
        services.AddMemoryCache();

        // Managed Identity in Azure; falls back through the default credential chain locally.
        services.AddSingleton(new SecretClient(keyVaultUri, new DefaultAzureCredential()));

        if (!string.IsNullOrWhiteSpace(redisConnectionString))
        {
            services.AddSingleton<IConnectionMultiplexer>(
                ConnectionMultiplexer.Connect(redisConnectionString));
        }

        services.AddSingleton<SnowflakeCredentialProvider>();
        services.AddScoped<ISnowflakeConnectionFactory, SnowflakeConnectionFactory>();
        services.AddScoped<ISnowflakeQueryExecutor, ResilientSnowflakeQueryExecutor>();

        return services;
    }
}

// ----------------------------------------------------------------------------
// Program.cs wiring (example)
// ----------------------------------------------------------------------------
/*
var builder = WebApplication.CreateBuilder(args);

// Existing Azure App Configuration setup — now holds ONLY endpoint/account info,
// no credentials and no sentinel key.
builder.Configuration.AddAzureAppConfiguration(options =>
{
    options.Connect(builder.Configuration["AppConfig:ConnectionString"])
           .Select("Snowflake:*");
});

builder.Services.AddSnowflakeResilience(
    builder.Configuration,
    keyVaultUri: new Uri(builder.Configuration["KeyVault:Uri"]!),
    redisConnectionString: builder.Configuration.GetConnectionString("Redis"));

// OpenTelemetry — add the Snowflake ActivitySource alongside your existing OTel setup
builder.Services.AddOpenTelemetry()
    .WithTracing(tracing => tracing
        .AddSource(SnowflakeTelemetry.SourceName)
        // ...your existing Dynatrace/OTel exporter config...
    );

var app = builder.Build();
*/

// ----------------------------------------------------------------------------
// Repository usage (example, MoneyIn)
// ----------------------------------------------------------------------------
/*
public sealed class MoneyInRepository
{
    private readonly ISnowflakeQueryExecutor _executor;

    public MoneyInRepository(ISnowflakeQueryExecutor executor) => _executor = executor;

    public Task<IReadOnlyList<MoneyInRecord>> GetAsync(string tenantId, DateRange range, CancellationToken ct) =>
        _executor.ExecuteAsync(async conn =>
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM MONEY_IN WHERE TENANT_ID = ? AND TXN_DATE BETWEEN ? AND ?";
            // ...bind parameters, execute, map to MoneyInRecord...
            return (IReadOnlyList<MoneyInRecord>)results;
        }, operationName: "GetMoneyIn", ct);
}
*/
